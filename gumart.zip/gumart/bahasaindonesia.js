const { HttpsProxyAgent } = require("https-proxy-agent");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const colors = require("colors");
const readline = require("readline");

const configPath = path.join(process.cwd(), "config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf8"));

const baseURL = "https://api.gumart.click/api"

class Gumart {
  constructor() {
    this.headers = {
      Accept: "application/json, text/plain, */*",
      "Accept-Encoding": "gzip, deflate, br",
      "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
      "Content-Type": "application/json",
      Origin: "https://d2kpeuq6fthlg5.cloudfront.net",
      Referer: "https://d2kpeuq6fthlg5.cloudfront.net/",
      "Sec-Ch-Ua":
        '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
      "Sec-Ch-Ua-Mobile": "?1",
      "Sec-Ch-Ua-Platform": '"Android"',
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-site",
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    };
    this.line = "~".repeat(42).white;
  }

  async waitWithCountdown(seconds) {
    for (let i = seconds; i >= 0; i--) {
      readline.cursorTo(process.stdout, 0);
      process.stdout.write(
        `===== Telah menyelesaikan semua akun, tunggu ${i} detik untuk melanjutkan siklus =====`
      );
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    console.log("");
  }

  getUserAgent(index) {
    const userAgentFilePath = path.join(__dirname, 'useragent.txt');
    const userAgents = fs.readFileSync(userAgentFilePath, 'utf-8').split('\n').filter(Boolean);
    const validUserAgents = userAgents.map(ua => ua.replace(/[^\x20-\x7E]/g, ''));
    return validUserAgents[index];
  }

  log(msg, proxyIP) {
    const time = new Date().toLocaleString("vi-VN", {
      timeZone: "Asia/Ho_Chi_Minh",
    });
    console.log(`[${time}] > ${proxyIP || "lokal"} > ${msg}`.cyan);
  }

  async sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async title() {
    console.clear();
    console.log(`
                ███████╗███████╗██████╗ ███╗   ███╗ ██████╗ 
                ╚══███╔╝██╔════╝██╔══██╗████╗ ████║██╔═══██╗
                  ███╔╝ █████╗  ██████╔╝██╔████╔██║██║   ██║
                 ███╔╝  ██╔══╝  ██╔═══╝ ██║╚██╔╝██║██║   ██║
                ███████╗███████╗██║     ██║ ╚═╝ ██║╚██████╔╝
                ╚══════╝╚══════╝╚═╝     ╚═╝     ╚═╝ ╚═════╝ 
                `);
    console.log(
      colors.yellow(
        "Alat ini dibuat oleh Gumart. Jika Anda merasa ini berguna, silakan dukung saya dengan 1 subscribe ya!"
      )
    );
    console.log(
      colors.blue(
        "Hubungi Telegram: https://t.me/@zepmoairdrop \n"
      )
    );
  }

  async login(data, proxy, index, proxyIP) {
    const url = `${baseURL}/login`;
    const header = {
      ...this.headers,
      "User-Agent": this.getUserAgent(index),
    };
    const payload = {
      "ref_id": config.ref_code,
      "telegram_data": data,
      "g_recaptcha_response": null,
      "mode": null
    }
    try {
      const response = await axios.post(url, payload, {
        headers: header,
        httpsAgent: new HttpsProxyAgent(proxy)
      });
      if (response.data.status_code === 200) {
        const user = response.data.data.user;
        this.log(`[Akun ${index}] ${user.username} | Saldo: ${user.total_gum} GUM !`.magenta, proxyIP);
        return response.data.data.access_token
      } else {
        this.log(`[Akun ${index}] Login gagal!`, proxyIP);
      }
    } catch (error) {
      this.log(`[Akun ${index}] Login gagal: ${error.message}`, proxyIP);
    }
  }

  async claimReward(token, proxy, index, proxyIP) {
    const url = `${baseURL}/claim`;
    const header = {
      ...this.headers,
      "User-Agent": this.getUserAgent(index),
      "Authorization": `Bearer ${token}`
    };
    try {
      const res = await axios.post(url, {}, {
        headers: header,
        httpsAgent: new HttpsProxyAgent(proxy)
      });
      if (res.data.status_code === 200) {
        this.log(`[Akun ${index}] (+) ${res.data.data.claim_value} GUM | Hadiah diklaim! | Saldo: ${res.data.data.balance} GUM !`.green, proxyIP);
      } else {
        this.log(`[Akun ${index}] Klaim gagal!`, proxyIP);
      }
    } catch (error) {
      this.log(`[Akun ${index}] Klaim gagal: ${error.message}`, proxyIP);
    }
  }

  async getMisson(token, proxy, index, proxyIP) {
    const url = `${baseURL}/missions`;
    const header = {
      ...this.headers,
      "User-Agent": this.getUserAgent(index),
      "Authorization": `Bearer ${token}`
    };
    try {
      const response = await axios.get(url, {
        headers: header,
        httpsAgent: new HttpsProxyAgent(proxy)
      });
      if (response.data.status_code === 200) {
        const missions = response.data.data.missions;
        const taskGroups = response.data.data.tasks;
        let tasks = []

        for (const group in taskGroups) {
          if (Array.isArray(taskGroups[group])) {
              tasks = [...tasks, ...taskGroups[group]];
          }
      }

        const combined = [...missions.daily, ...missions.fixed, ...tasks];
        return combined;
        
      } else {
        this.log(`[Akun ${index}] Gagal mendapatkan misi!`.red, proxyIP);
      }
    } catch (error) {
      this.log(`[Akun ${index}] Gagal mendapatkan misi: ${error.message}`.red, proxyIP);
    }
  }


    async startMission(token, mission, proxy, index, proxyIP) {
      const url = `${baseURL}/missions/${mission.id}/start`;
      const header = {
        ...this.headers,
        "User-Agent": this.getUserAgent(index),
        "Authorization": `Bearer ${token}`
      }
      try {
        const response = await axios.post(url, {}, {
          headers: header,
          httpsAgent: new HttpsProxyAgent(proxy)
        });
        if (response.data.status_code === 200) {
          this.log(`[Akun ${index}] Memulai misi ${mission.description} sukses!`.blue, proxyIP);
          return true
        } else {
          this.log(`[Akun ${index}] Memulai misi ${mission.description} gagal!`.red, proxyIP);
          return false
        }
      } catch (error) {
        this.log(`[Akun ${index}] Memulai misi ${mission.description} gagal: ${error.message}`.red, proxyIP);
        return false
      }
    }

    async completeMission(token, mission, proxy, index, proxyIP) {
      const url = `${baseURL}/missions/${mission.id}/claim`;
      const header = {
        ...this.headers,
        "User-Agent": this.getUserAgent(index),
        "Authorization": `Bearer ${token}`
    }
    try {
      const res = await axios.post(url, {}, {
        headers: header,
        httpsAgent: new HttpsProxyAgent(proxy)
      });
      if (res.data.status_code === 200) {
        this.log(`[Akun ${index}] (+) ${mission.point} GUM | Menyelesaikan misi ${mission.description} sukses!`.green, proxyIP);
      } else {
        this.log(`[Akun ${index}] Menyelesaikan misi ${mission.description} gagal: ${res.data.message}`.red, proxyIP);
      }
    } catch (error) {
      this.log(`[Akun ${index}] Menyelesaikan misi ${mission.description} gagal: ${error.message}`.red, proxyIP);
    }
  }


  async process(data, proxy, index) {
    const proxyIP = proxy.split("@")[1] || "lokal";
    const token = await this.login(data, proxy, index, proxyIP);
    if (token) {
      const missions = await this.getMisson(token, proxy, index, proxyIP);
      if (missions && config.is_do_task) {
        for (const mission of missions) {
          if (mission?.status == "startable") {
            await this.startMission(token, mission, proxy, index, proxyIP);
          }
          else if (mission?.status == "claimable") {
            await this.completeMission(token, mission, proxy, index, proxyIP);
          }
        }
      }
      await this.claimReward(token, proxy, index, proxyIP);
    }
  }

  async main() {
    await this.title();
    const dataFile = path.join(process.cwd(), "data.txt");
    const data = fs
      .readFileSync(dataFile, "utf8")
      .replace(/\r/g, "")
      .split("\n")
      .filter(Boolean);

    const proxyFile = path.join(process.cwd(), "proxy.txt");
    const proxyList = fs
      .readFileSync(proxyFile, "utf8")
      .replace(/\r/g, "")
      .split("\n")
      .filter(Boolean);

    if (data.length <= 0) {
      this.log("Tidak ada akun yang ditambahkan!".red);
      await this.sleep(5000);
      process.exit();
    }

    if (proxyList.length <= 0) {
      this.log("Tidak ada proxy yang ditambahkan!".red);
      await this.sleep(5000);
      process.exit();
    }
    while (true) {
      const threads = [];
      for (const [index, tgData] of data.entries()) {
        const proxy = proxyList[index % proxyList.length];
        threads.push(this.process(tgData, proxy, index + 1));
        if (threads.length >= config.threads) {
          console.log(`Sedang menjalankan ${threads.length} proses thread...`.bgYellow);
          await Promise.all(threads);
          threads.length = 0;
        }
      }
      if (threads.length > 0) {
        console.log(`Sedang menjalankan ${threads.length} proses thread...`.bgYellow);
        await Promise.all(threads);
      }
      await this.waitWithCountdown(config.wait_time);
    }
  }
}

if (require.main === module) {
  process.on("SIGINT", () => {
    process.exit();
  });
  new Gumart().main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}
